</div>
</div>
</div>
</div>
</div>
</div>


<!-- Footer Area Start -->
<footer class="main-footer footer-two bg-blue-two text-white">
    <div class="container">
        <!-- <div class="logo-inner style-two pt-85 pb-35">
                    <div class="logo-item">
                        <a href="about.html"><img src="public/assets/images/client-logos/client-logo-two1.png" alt="Client Logo"></a>
                    </div>
                    <div class="logo-item">
                        <a href="about.html"><img src="public/assets/images/client-logos/client-logo-two5.png" alt="Client Logo"></a>
                    </div>
                    <div class="logo-item">
                        <a href="about.html"><img src="public/assets/images/client-logos/client-logo-two3.png" alt="Client Logo"></a>
                    </div>
                    <div class="logo-item">
                        <a href="about.html"><img src="public/assets/images/client-logos/client-logo-two4.png" alt="Client Logo"></a>
                    </div>
                    <div class="logo-item">
                        <a href="about.html"><img src="public/assets/images/client-logos/client-logo-two2.png" alt="Client Logo"></a>
                    </div>
                    <div class="logo-item">
                        <a href="about.html"><img src="public/assets/images/client-logos/client-logo-two6.png" alt="Client Logo"></a>
                    </div>
                </div> -->
        <div class="row large-gap justify-content-between pt-85">
            <div class="col-lg-3 col-sm-4">
                <div class="footer-widget about-widget">
                    <div class="footer-logo mb-25">
                        <a href="index.html"><img src="public/assets/images/logos/2.png" alt="Logo"></a>
                    </div>
                    <p>Vip Digital Hub Coaching Institute in Balaghat . IT is Best Computer Education Institute in balaghat. </p>
                    <div class="social-style-one pt-10">
                        <a href="index.php"><i class="fab fa-facebook-f"></i></a>
                        <a href="index.php"><i class="fab fa-twitter"></i></a>
                        <a href="index.php"><i class="fab fa-linkedin-in"></i></a>
                        <a href="index.php"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4">
                <div class="footer-widget menu-widget">
                    <h5 class="footer-title">Courses</h5>
                    <ul>
                        <li><a href="index.php">Web Development</a></li>
                        <li><a href="index.php"> App Development</a></li>
                        <li><a href="index.php">Digital Marketing </a></li>

                        <li><a href="index.php">Web Design</a></li>
                        <li><a href="index.php">SEO Optimize</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-4">
                <div class="footer-widget contact-info-widget">
                    <h5 class="footer-title">Get In Touch</h5>
                    <ul>
                        <li><i class="fas fa-map-marker-alt"></i> Balaghat M.P</li>
                        <li><i class="far fa-envelope"></i> <a href="#">info@vipdigitalhub.in</a></li>
                        <li><i class="fas fa-phone"></i> <a href="callto:+0123456789"> +91 7000153244</a></li>
                        <li><i class="far fa-clock"></i> Sunday - Friday,<br> 08 am - 05 pm</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="footer-widget menu-widget">

                    <h5 class="footer-title">Courses</h5>
                    <ul>
                        <li><a href="index.php">Web Development</a></li>
                        <li><a href="index.php"> App Development</a></li>
                        <li><a href="index.php">Digital Marketing </a></li>

                        <li><a href="index.php">Web Design</a></li>
                        <li><a href="index.php">SEO Optimize</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="copyright-area rel">
        <div class="container">
            <div class="copyright-inner">
                <p>© 2022. <a href="vipdigitalhub.in">Vip Digital Hub </a> All rights reserved.</p>
                <ul class="footer-menu">
                    <li><a href="index.php">Faqs</a></li>
                    <li><a href="index.php">Links</a></li>
                    <li><a href="index.php">About</a></li>
                    <li><a href="index.php">Payments</a></li>
                </ul>
            </div>
        </div>
        <!-- Scroll Top Button -->
        <button class="scroll-top scroll-to-target" data-target="html"><span class="fas fa-angle-double-up"></span></button>
    </div>
</footer>
<!-- Footer Area End -->

</div>
<!--End pagewrapper-->
