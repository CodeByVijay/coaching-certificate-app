<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('main-containt'); ?>

    <div class="content-inner">
        <!-- Page Header-->
        <header class="page-header">
            <div class="container-fluid">
                <h2 class="no-margin-bottom">Dashboard</h2>
            </div>
        </header>
        <!-- Dashboard Counts Section-->

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <p><?php echo e(session()->get('success')); ?></p>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        
        <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
                <div class="row bg-white has-shadow">
                    <!-- Item -->
                    <div class="col-xl-3 col-sm-6">
                        <div class="item d-flex align-items-center">
                            <div class="icon bg-violet"><i class="icon-user"></i></div>
                            <div class="title"><span>New<br>Student</span>
                                <div class="progress">
                                    <div role="progressbar" style="width: <?php echo e($totalNewStudent); ?>%; height: 4px;"
                                        aria-valuenow="<?php echo e($totalNewStudent); ?>" aria-valuemin="0" aria-valuemax="100"
                                        class="progress-bar bg-violet"></div>
                                </div>
                            </div>
                            <div class="number"><strong><?php echo e($totalNewStudent); ?></strong></div>
                        </div>
                    </div>
                    <!-- Item -->
                    <div class="col-xl-3 col-sm-6">
                        <div class="item d-flex align-items-center">
                            <div class="icon bg-red"><i class="icon-padnote"></i></div>
                            <div class="title"><span>Student<br>Enrolled</span>
                                <div class="progress">
                                    <div role="progressbar" style="width: <?php echo e($totalStudentEnroll); ?>%; height: 4px;"
                                        aria-valuenow="<?php echo e($totalStudentEnroll); ?>" aria-valuemin="0" aria-valuemax="100"
                                        class="progress-bar bg-red"></div>
                                </div>
                            </div>
                            <div class="number"><strong><?php echo e($totalStudentEnroll); ?></strong></div>
                        </div>
                    </div>
                    <!-- Item -->
                    <div class="col-xl-3 col-sm-6">
                        <div class="item d-flex align-items-center">
                            <div class="icon bg-green"><i class="icon-bill"></i></div>
                            <div class="title"><span>Get<br>Certificate</span>
                                <div class="progress">
                                    <div role="progressbar" style="width: <?php echo e($totalIssuedCertificate); ?>%; height: 4px;"
                                        aria-valuenow="<?php echo e($totalIssuedCertificate); ?>" aria-valuemin="0" aria-valuemax="100"
                                        class="progress-bar bg-green"></div>
                                </div>
                            </div>
                            <div class="number"><strong><?php echo e($totalIssuedCertificate); ?></strong></div>
                        </div>
                    </div>
                    <!-- Item -->
                    <div class="col-xl-3 col-sm-6">
                        <div class="item d-flex align-items-center">
                            <div class="icon bg-orange"><i class="icon-check"></i></div>
                            <div class="title"><span>Open<br>Query</span>
                                <div class="progress">
                                    <div role="progressbar" style="width: <?php echo e($totalQuerys); ?>%; height: 4px;"
                                        aria-valuenow="<?php echo e($totalQuerys); ?>" aria-valuemin="0" aria-valuemax="100"
                                        class="progress-bar bg-orange"></div>
                                </div>
                            </div>
                            <div class="number"><strong><?php echo e($totalQuerys); ?></strong></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Dashboard Header Section    -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coaching-certificate-app-laravel-8/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>