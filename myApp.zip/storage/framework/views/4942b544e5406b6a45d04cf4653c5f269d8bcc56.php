<!DOCTYPE html>
<html lang="zxx">

<head>
    <!--====== Required meta tags ======-->
    <meta charset="utf-8" />
    <meta name="description" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <!--====== Title ======-->
    <title>Vip Digital Hub - <?php echo $__env->yieldContent('title'); ?></title>
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
    <!--====== Google Fonts ======-->
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;500;600;700&family=Oswald:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <!--====== Flaticon ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.min.css')); ?>">
    <!--====== Font Awesome ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome-5.9.0.min.css')); ?>">
    <!--====== Bootstrap ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-4.5.3.min.css')); ?>">
    <!--====== Magnific Popup ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.min.css')); ?>">
    <!--====== Nice Select ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/nice-select.min.css')); ?>">
    <!--====== jQuery UI ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.min.css')); ?>">
    <!--====== Animate ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <!--====== Slick ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.min.css')); ?>">
    <!--====== Main Style ======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <style>

        input[type=text] {
          border: 2px solid red;
          border-radius: 4px;
          width: 450px;
        }

        </style>
<?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('containt'); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!--====== Jquery ======-->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <!--====== Bootstrap ======-->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <!--====== Appear Js ======-->
    <script src="<?php echo e(asset('assets/js/appear.min.js')); ?>"></script>
    <!--====== Slick ======-->
    <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
    <!--====== jQuery UI ======-->
    <script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
    <!--====== Isotope ======-->
    <script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
    <!--====== Circle Progress bar ======-->
    <script src="<?php echo e(asset('assets/js/circle-progress.min.js')); ?>"></script>
    <!--====== Images Loader ======-->
    <script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <!--====== Nice Select ======-->
    <script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
    <!--====== Magnific Popup ======-->
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <!--  WOW Animation -->
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <!-- Custom script -->
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>


</body>

</html>
<?php /**PATH /var/www/html/coaching-certificate-app-laravel-8/resources/views/partials/app.blade.php ENDPATH**/ ?>