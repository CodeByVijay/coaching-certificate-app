<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Vip Digital hub - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/fontastic.css')); ?>">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.default.css')); ?>" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/custom.css')); ?>">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/admin/img/favicon.ico')); ?>">
    <!-- Tweaks for older IEs-->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
        <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>

    <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('main-containt'); ?>
    <?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('assets/admin/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/popper.js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery.cookie/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/charts-home.js')); ?>"></script>
    <!-- Main File-->
    <script src="<?php echo e(asset('assets/admin/js/front.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH /var/www/html/coaching-certificate-app-laravel-8/resources/views/admin/partials/app.blade.php ENDPATH**/ ?>